package com.batch.example.model;

public class Product {

   private String productId;
   private String incidentState;
   private String incidentLocation;
   private String age;
   private String policyNumber;
   private String policyDeductable;
   private String autoMake;
   private String autoYear;

    public Product(String productId, String incidentState, String incidentLocation, String age, String policyNumber, String policyDeductable, String autoMake, String autoYear) {
        this.productId = productId;
        this.incidentState = incidentState;
        this.incidentLocation = incidentLocation;
        this.age = age;
        this.policyNumber = policyNumber;
        this.policyDeductable = policyDeductable;
        this.autoMake = autoMake;
        this.autoYear = autoYear;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getIncidentState() {
        return incidentState;
    }

    public void setIncidentState(String incidentState) {
        this.incidentState = incidentState;
    }

    public String getIncidentLocation() {
        return incidentLocation;
    }

    public void setIncidentLocation(String incidentLocation) {
        this.incidentLocation = incidentLocation;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getPolicyDeductable() {
        return policyDeductable;
    }

    public void setPolicyDeductable(String policyDeductable) {
        this.policyDeductable = policyDeductable;
    }

    public String getAutoMake() {
        return autoMake;
    }

    public void setAutoMake(String autoMake) {
        this.autoMake = autoMake;
    }

    public String getAutoYear() {
        return autoYear;
    }

    public void setAutoYear(String autoYear) {
        this.autoYear = autoYear;
    }

    public Product() {

    }
}

