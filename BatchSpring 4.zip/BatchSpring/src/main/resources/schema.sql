CREATE  TABLE IF NOT EXISTS products
(
    product_id varchar(100) primary key,
    incidentState varchar(200),
    incidentLocation varchar(200),
    age varchar(10),
    policyNumber varchar(200),
    policyDeductable varchar(200),
    autoMake varchar(200),
    autoYear varchar(100)
);