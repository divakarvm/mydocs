package org.vam.ca.application.gateway.quote;

import org.vam.ca.domain.Quote;

public interface CreateQuoteGateway {
   public String create(Quote quote);
}
