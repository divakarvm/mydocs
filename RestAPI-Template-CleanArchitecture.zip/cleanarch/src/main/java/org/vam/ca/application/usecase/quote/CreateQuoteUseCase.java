package org.vam.ca.application.usecase.quote;

import org.vam.ca.domain.Quote;

public interface CreateQuoteUseCase {
    public String createQuote(Quote quote);

}
