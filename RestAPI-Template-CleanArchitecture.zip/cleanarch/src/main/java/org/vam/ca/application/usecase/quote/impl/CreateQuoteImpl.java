package org.vam.ca.application.usecase.quote.impl;

import org.vam.ca.application.gateway.quote.CreateQuoteGateway;
import org.vam.ca.application.usecase.quote.CreateQuoteUseCase;
import org.vam.ca.domain.Quote;

public class CreateQuoteImpl implements CreateQuoteUseCase {
    private CreateQuoteGateway createQuoteGateway;

    public CreateQuoteImpl(CreateQuoteGateway createQuoteGateway) {
        this.createQuoteGateway = createQuoteGateway;
    }

    @Override
    public String createQuote(Quote quote) {
        return createQuoteGateway.create(quote);
    }
}
