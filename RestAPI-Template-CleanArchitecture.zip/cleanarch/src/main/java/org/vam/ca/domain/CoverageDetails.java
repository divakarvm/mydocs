package org.vam.ca.domain;

public class CoverageDetails {
}
