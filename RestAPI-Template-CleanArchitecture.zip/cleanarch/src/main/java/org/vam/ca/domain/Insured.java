package org.vam.ca.domain;

import lombok.Data;

@Data
public class Insured {
    public String name;
    public Address address;
   // public ContactDetails contactDetails;
}
