package org.vam.ca.domain;

public class PremiumDetails {
}
