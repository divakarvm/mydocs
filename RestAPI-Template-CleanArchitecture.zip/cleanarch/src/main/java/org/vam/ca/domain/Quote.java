package org.vam.ca.domain;

import lombok.Data;

@Data
public class Quote {
    private Long quoteId;
    private String quoteType;
    private String quoteStatus;
    private Address address;
   // public Insured insured;
   /* public PropertyDetails propertyDetails;
    public CoverageDetails coverageDetails;
    public PremiumDetails premiumDetails;
    public AdditionalDetails additionalDetails;*/

}
