package org.vam.ca.infrastructure.config;

import org.vam.ca.application.usecase.quote.CreateQuoteUseCase;
import org.vam.ca.application.usecase.quote.impl.CreateQuoteImpl;
import org.vam.ca.infrastructure.gateway.CreateQuoteGatewayImpl;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    public CreateQuoteUseCase createQuote(CreateQuoteGatewayImpl gatewayImpl){
        return new CreateQuoteImpl(gatewayImpl);
    }
    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }


}
