package org.vam.ca.infrastructure.gateway;

import org.vam.ca.application.gateway.quote.CreateQuoteGateway;
import org.vam.ca.domain.Quote;
import org.vam.ca.infrastructure.persistence.entity.QuoteEntity;
import org.vam.ca.infrastructure.persistence.repository.QuoteRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component

public class CreateQuoteGatewayImpl implements CreateQuoteGateway {

    private QuoteRepository quoteRepository;
   private ModelMapper modelMapper;
    public CreateQuoteGatewayImpl(QuoteRepository quoteRepository, ModelMapper modelMapper) {
        this.quoteRepository = quoteRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public String create(Quote quote) {
        QuoteEntity quoteEntity = modelMapper.map(quote, QuoteEntity.class);
        quoteRepository.save(quoteEntity);
        return "Quote created successfully"+quote.getQuoteId();
    }
}
