package org.vam.ca.infrastructure.persistence.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Quote")
public class QuoteEntity {
    @Id
    private Long quoteId;
    private String quoteType;
    private String quoteStatus;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_id")
    private AddressEntity address;
}
