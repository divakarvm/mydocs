package org.vam.ca.interfaces.controller;

import org.vam.ca.application.usecase.quote.CreateQuoteUseCase;
import org.vam.ca.domain.Quote;
import org.modelmapper.ModelMapper;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class QuoteController {
    private final CreateQuoteUseCase createQuoteUseCase;
    private ModelMapper modelMapper;
    public QuoteController(CreateQuoteUseCase createQuoteUseCase, ModelMapper modelMapper) {
        this.createQuoteUseCase = createQuoteUseCase;
        this.modelMapper = modelMapper;
    }
    @PostMapping("quote")
    public String createQuote(@RequestBody Quote quote){
         //Quote quote = modelMapper.map(request, Quote.class);
        return createQuoteUseCase.createQuote(quote);
    }
}
