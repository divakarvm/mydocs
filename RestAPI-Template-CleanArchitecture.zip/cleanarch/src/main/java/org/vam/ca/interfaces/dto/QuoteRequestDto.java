package org.vam.ca.interfaces.dto;

import lombok.Data;

@Data
public class QuoteRequestDto {
    private long quoteId;
    private String quoteType;
    private String quoteStatus;
}

