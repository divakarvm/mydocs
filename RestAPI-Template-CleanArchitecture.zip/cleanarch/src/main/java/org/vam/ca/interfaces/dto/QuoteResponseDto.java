package org.vam.ca.interfaces.dto;

public class QuoteResponseDto {
}
